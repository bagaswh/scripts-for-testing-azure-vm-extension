sudo apt install -y nginx
